
import time_series_visualizer as tsv

tsv.draw_line_plot()
tsv.draw_bar_plot()
tsv.draw_box_plot()
